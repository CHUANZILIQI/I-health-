#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_

#include "main.h"

void Interrupt_Set(void);

#endif
