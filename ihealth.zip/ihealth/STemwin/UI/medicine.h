#ifndef _MEDICINE_H_
#define _MEDICINE_H_

#include <stdlib.h>
#include "GUI.h"
#include "DIALOG.h"

WM_HWIN Create_MedicineWindow(void);

#endif
