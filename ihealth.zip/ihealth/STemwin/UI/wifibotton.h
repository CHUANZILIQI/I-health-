#ifndef _WIFIBOTTON_H_
#define _WIFIBOTTON_H_

#include <stdlib.h>
#include "GUI.h"

#endif
